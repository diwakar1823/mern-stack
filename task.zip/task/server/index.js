const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const path = require("path");
require('dotenv').config({ path: __dirname + '/.env' }); // Explicitly load .env file

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log("Connected to DB"))
  .catch((err) => console.log("Failed to connect to DB:", err.message));


// Schema
const schemaData = mongoose.Schema({
  name: String,
  email: String,
  mobile: String,
}, {
  timestamps: true
});

// Model
const userModel = mongoose.model("user", schemaData);

// API Routes
// Read
app.get("/api/users", async (req, res) => {
  try {
    const data = await userModel.find({});
    res.json({ success: true, data: data });
  } catch (error) {
    console.error("Error fetching data:", error); // Added detailed error logging
    res.status(500).send({ success: false, message: "Failed to fetch data", error: error.message });
  }
});

// Create data || Save data in MongoDB
app.post("/api/users", async (req, res) => {
  try {
    const data = new userModel(req.body);
    await data.save();
    res.send({ success: true, message: "Data saved successfully", data: data });
  } catch (error) {
    console.error("Error saving data:", error); // Added detailed error logging
    res.status(500).send({ success: false, message: "Failed to save data", error: error.message });
  }
});

// Update data
app.put("/api/users/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    const data = await userModel.updateOne({ _id: id }, updateData);
    res.send({ success: true, message: "Data updated successfully", data: data });
  } catch (error) {
    console.error("Error updating data:", error); // Added detailed error logging
    res.status(500).send({ success: false, message: "Failed to update data", error: error.message });
  }
});

// Delete data
app.delete("/api/users/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const data = await userModel.deleteOne({ _id: id });
    res.send({ success: true, message: "Data deleted successfully", data: data });
  } catch (error) {
    console.error("Error deleting data:", error); // Added detailed error logging
    res.status(500).send({ success: false, message: "Failed to delete data", error: error.message });
  }
});

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../client/build')));

// Handle React routing, return all requests to React app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
});

// Start server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));
